//**********************************************************************************
// ���ѥ�������إ� validate list ������C
//**********************************************************************************
function Validator(){
	this.checkObjectList = new Array();
	this.define = Validator_define;
	this.validate = Validator_validate;
	this.validateOld = Validator_validateOld;
	this.clear = Validator_clear;
	this.errHandler = new AlertHandler;
}
//**********************************************************************************
// �M���w�w�q�n�� validate list�A�H�Q���s�w�q validate list
//**********************************************************************************
function Validator_clear(){
	this.checkObjectList = new Array();
	this.errHandler.clear();
}
//**********************************************************************************
// �v�@���� validate list �����C�@�� check ojbect �� validate method
// �Y���� validate �����G�O false ���A�h�|�ݬO�_���w�q errHandler�C
// �Y�����ܷ|�N check object �ǵ� errHandler�C
//**********************************************************************************
function Validator_validate(){
	this.errHandler.clear();
	var tmpObj;
	var result = true;
	for(var i=0;i<this.checkObjectList.length;i++){
		tmpObj = this.checkObjectList[i];
		if(!tmpObj.element || tmpObj.element.disabled){ continue; }
		var rt = tmpObj.validate($F(tmpObj.element),tmpObj.min,tmpObj.max);
		if(typeof(rt) == 'string'){
			tmpObj.errMsg = rt;
			rt = false;	
		}else if(typeof(rt)=='object' && rt['errMsg']){
			tmpObj.errMsg = rt['errMsg'];
			rt = false;
		}
		if(!rt){
			result = false;
			if(this.errHandler){
				if((typeof this.errHandler)=='function'){
					this.errHandler(tmpObj);
				}else{
					this.errHandler.handle(tmpObj);
				}
			}	
		}
	}
	
	if(!result) this.errHandler.display();
	return result;
}
//�P�W, ���|����display message
function Validator_validateOld(){
	//this.errHandler.clear();
	var tmpObj;
	var result = true;
	for(var i=0;i<this.checkObjectList.length;i++){
		tmpObj = this.checkObjectList[i];
		if(!tmpObj.element || tmpObj.element.disabled){ continue; }
		var rt = tmpObj.validate($F(tmpObj.element),tmpObj.min,tmpObj.max);
		if(typeof(rt) == 'string'){
			tmpObj.errMsg = rt;
			rt = false;	
		}else if(typeof(rt)=='object' && rt['errMsg']){
			tmpObj.errMsg = rt['errMsg'];
			rt = false;
		}
		if(!rt){
			result = false;
			if(this.errHandler){
				if((typeof this.errHandler)=='function'){
					this.errHandler(tmpObj);
				}else{
					this.errHandler.handle(tmpObj);
				}
			}	
		}
	}
	
	//if(!result) this.errHandler.display();
	return result;
}
//**********************************************************************************
// �N�C�@�ӭn�ˮ֪����W�٤��ˮ֫��A�B����B�Φ۩w����k�]�w�i�h�C
// n - field name (Required)
// desc - ��쪺���� (Should define)
// errMsg - �Y�O�ˮֿ��~���^���T�� (Should define)
// type - validate type (string, num, date, option Function Name) (Required)
// min - �̤p��
// max - �̤j��
//**********************************************************************************
function Validator_define(n,desc,errMsg,type,min,max){
	this.checkObjectList.push(new CheckObject(n,desc,errMsg,type,min,max));
}
//-------------------------------------------------------------------------
// �� check object �� Validator �����ާ@����ƪ���C
// �C�@�� check object ��a�F��@������ˮ֪�������ơC
// �ݩʤθ�ƴy�z�p�U:
// name - �n�Q�ˮ֪����W��(element �� name)
// element - �n�Q�ˮ֪� element
// desc - ����쪺����
// errMsg - �Y�ˮֿ��~�ɭn��ܪ����~�T��
// type - �]�w���ˮ֫��A(�Φ۩w���ˮ� function name)
// min - �ˮ֪�����1
//	    (�r���ˮ֮ɬ����ת��̤p�ȡA�Ʀr�ɬ��ƭȪ��̤p�ȡC
//       �Y���۩w�� function�A�h�|�N���ܼƩұa������ǵ�
//       �� function �����������)
// max - �ˮ֪�����2
//	    (�r���ˮ֮ɬ����ת��̤j�ȡA�Ʀr�ɬ��ƭȪ��̤j�ȡC
//       �Y���۩w�� function�A�h�|�N���ܼƩұa������ǵ�
//       �� function �����������)
// validate - ��ڰ��� validate �� function�C�|�� Validator �өI�s�C
// 
//-------------------------------------------------------------------------
function CheckObject(n,desc,errMsg,type,min,max){
	this.name = n;
	this.element = $(n);
	this.desc = desc;
	this.errMsg = errMsg;
	this.type = type;
	this.min = min;
	this.max = max;
	this.validate;
	
	if(!this.element) throw new Error("Can't find the input element, name=[" + n + "]");
	
	if(typeof(type) == 'function'){
		this.validate = type;
	}else{
		switch(type.toUpperCase()){
			default: {var func=window[type]; if(func){this.validate=func;}else{throw new Error("Can't find the Validate function [" + type + "]");}break;}
			case 'STRING' : {this.validate=validateString;break;};
			case 'NUM' : {this.validate=validateNum;break;};
			case 'SELECT' : {this.validate=validateSelect;break;};
			case 'DATE' : {this.validate=validateDate;break;};
			case 'STRING_BYTES' : {this.validate=validateStringBytes;break;};
			case 'CHECKED' : {this.validate=validateChecked;break;};
			case 'DATE_INPUT' : {this.validate=validateDateInput;break;};
		}		
	}
}
//***************************************************************************
// Default validate function for string and number type.
//***************************************************************************
function validateString(v,min,max){
	var len = v.length;
	if( min && max && (len<min || len>max) ){
		return false;
	}else if( min && !max && (len<min) ){
		return false;
	}else if( !min && max && (len>max)){
		return false;
	}else if( !min && !max && (len<=0) ){
		return false;
	}
	return true;
}
//------------------------------------------------------------------------------
function validateNum(v,min,max){
	var len = v.length;
	var checkMin = !isNaN(parseInt(min));
	var checkMax = !isNaN(parseInt(max)); 
	if( (len<=0) || (isNaN(v)) ){
		return false;
	}else if( checkMin && checkMax && (v<min || v>max) ){
		return false;
	}else if( !checkMin && checkMax && (v>max) ){
		return false;
	}else if( checkMin && !checkMax && (v<min) ){
		return false;
	}
	return true;
}
//------------------------------------------------------------------------------
function validateSelect(v) {
	if (v == '') {
		return false;
	}
	return true;
}
//------------------------------------------------------------------------------
//�ˮ֦褸�~ YYYYMMDD or YYYY-MM-DD or YYYY/MM/DD
function validateDateInput(v) {

	v = v.replace('/',  '');
	v = v.replace('-',  '');
	v = v.replace('/',  '');
	v = v.replace('-',  '');
		
	var data = v.match(/^(\d{4})(\d{2})(\d{2})$/);
	if (!data || !v) {
		return false;
	}
	var d = new Date(RegExp.$1 + "/" + RegExp.$2 + "/" + RegExp.$3);
	if (d.getMonth() != (RegExp.$2-1) || d.getDate() != RegExp.$3) {
		return false;
	}
	return true;
	
}
//------------------------------------------------------------------------------
//�ˮ֦褸�~
function validateDate(v) {
	var data = v.match(/^(\d{4})(\d{2})(\d{2})$/);
	if (!data || !v) {
		return false;
	}
	var d = new Date(RegExp.$1 + "/" + RegExp.$2 + "/" + RegExp.$3);
	if (d.getMonth() != (RegExp.$2-1) || d.getDate() != RegExp.$3) {
		return false;
	}
	return true;
}
//------------------------------------------------------------------------------
// add by dave
function validateChecked(value,min,max,obj) {

	var list = document.getElementsByName(obj.name);
	
	for (var i=0;i<list.length;i++) {
		if (list[i].checked == true) {
			return true;
		}
	}

	return false;
}
//------------------------------------------------------------------------------
//�Hbyte����ˬd�r�����
var twoBytesRegExp = /[^\x00-\xff]/g;
function validateStringBytes(v, min, max) {
    var len = v.replace(twoBytesRegExp, "rr").length;
	if (min && max && (len < min || len > max)) {
		return false;
	} else if (min && !max && len < min) {
		return false;
	} else if (!min && max && len > max) {
		return false;
	} else if (!min && !max && len <= 0) {
		return false;
	}
	return true;
}
//**************************************************************************
// Default AlertHandler for display error message
//**************************************************************************
function AlertHandler (){
	this.msg = new Array();
	this.markList = new Array();
	this.handle = Alert_handle;
	this.display = Alert_display;
	this.mark = Alert_mark;
	this.clear = Alert_clear;
	this.focus = Alert_focus();
}
//---------------------------------------------------
function Alert_focus () {
	if(this.markList && this.markList[0]){
		this.markList[0].focus();
	}
}
//---------------------------------------------------
//�@�w�n�w�q�� method�A���쪺�ѼƬ� check object
function Alert_handle(obj){
	this.msg.push(obj.desc + "[" + obj.errMsg + "]");
	this.mark(obj.element);
}
//---------------------------------------------------
function Alert_mark(e){
	this.markList.push(e);
	e.style.backgroundColor = "#FF8888";
}
//---------------------------------------------------
function Alert_clear(){
	this.msg = new Array();
	this.focusElement = null;
	
	for(var i=0;i<this.markList.length;i++){
		
		this.markList[i].style.backgroundColor = "";
	}
	this.markList = new Array();
}
//---------------------------------------------------
function Alert_display(){
	var str = "�ˮֿ��~�p�U:\n";
	for(var i=0; i<this.msg.length;i++){
		str += this.msg[i] + "\n";
	}
	alert(str);
}