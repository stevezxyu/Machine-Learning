/*
* Really easy field validation with Prototype
* http://tetlaw.id.au/view/javascript/really-easy-field-validation
* Andrew Tetlaw
* Version 1.5.4.1 (2007-01-05)
* 
* Copyright (c) 2007 Andrew Tetlaw
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use, copy,
* modify, merge, publish, distribute, sublicense, and/or sell copies
* of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
* 
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
* BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
* ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
* CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*/

/**
 *  @public
 *	@class �w�ﭶ���������ƶi��������
 *	@author 
 *	@version 1.0
 **/ 
String.prototype.Blength = function () {
	var len = this.length;
	var arr = this.match(/[^u4e00-u9fa5]/ig);
	return arr == null ? len : len + arr.length;
}
 
//multiTest �P�_���ˮ֡A�O�_���h���ˮ� add by adin
var Validator = Class.create({
	initialize : function(className, error, test, options ) {
		if(typeof test == 'function'){
			this.options = $H(options);
			this._test = test;
		} else {
			this.options = $H(test);
			this._test = function(){return true};
		}
	
		this.error = error || '��J�ˮֿ��~.';
		this.className = className;
	},
	test : function(v, elm , info) { // info : add by dave  
		if( info && info.multiTest == true){		 // multiTest �� true �ɡA�Ĥ@�ӰѼƶǤJ inputs���}�C add by Adin (���F�ʺA)
			return this._test.apply( this , v );
		}
		return (this._test(v,elm,info) && this.options.all(function(p){
			return Validator.methods[p.key] ? Validator.methods[p.key](v,elm,Validation.getElementValue(p)) : true;
		}));
	}
});

Validator.methods = {
	pattern : function(v,elm,opt) {return Validation.get('IsEmpty').test(v) || opt.test(v)},
	minLength : function(v,elm,opt) {return v.Blength() >= opt},
	maxLength : function(v,elm,opt) {return v.Blength() <= opt},
	min : function(v,elm,opt) {return v >= parseFloat(opt)}, 
	max : function(v,elm,opt) {return v <= parseFloat(opt)},
	gt : function(v,elm,opt) {return v > parseFloat(opt)}, 
	lt : function(v,elm,opt) {return v < parseFloat(opt)},
	notOneOf : function(v,elm,opt) {return $A(opt).all(function(value) {
		return v != value;
	})},
	oneOf : function(v,elm,opt) {return $A(opt).any(function(value) {
		return v == value;
	})},
	is : function(v,elm,opt) {return v == opt},
	isNot : function(v,elm,opt) {return v != opt},
	equalToField : function(v,elm,opt) {return v == $F(opt)},
	notEqualToField : function(v,elm,opt) {return v != $F(opt)},
	include : function(v,elm,opt) {return $A(opt).all(function(value) {
		return Validation.get(value).test(v,elm);
	})}
} 
 
//instance methods
var Validation = Class.create({
	initialize : function(form, options){
		//�w�]��
		this.options = Object.extend({
			onSubmit : true,
			stopOnFirst : false,
			immediate : false,
			focusOnError : true,
			useTitles : false,
			checkReadOnly : true,
			checkDisabled : false,
			onFormValidate : function(result, form) {},
			onElementValidate : function(result, elm) {},
			toNextError : true,
			notIgnoreHidden : false,
			mode : Validation.defaultManner
		}, options || {});
						
		Validation.mode = Validation.manner[this.options["mode"]];
		
		this.verifyList= {};  //�s��h���ˮ֪�����
		
		this.form = $(form);
		if(this.options.onSubmit) Event.observe(this.form,'submit',this.onSubmit.bind(this),false);
		
		if(this.options.immediate) {
			var useTitles = this.options.useTitles;
			var callback = this.options.onElementValidate;
			var toNextError = this.options.toNextError;
			Form.getElements(this.form).each(function(input) { // Thanks Mike!
				Event.observe(input, 'change', function(event) {
					//showAlert add by adin �ΨӰ�validator���Y���ˮ֥Ϊ�
					var check = Validation.mode.validate( event.target ,{useTitle : useTitles, onElementValidate : callback } , {showAlert : true});
					if( check && toNextError){	//�O�_�n����U�@�ӿ��~
						Validation.focusNextErrorElement( input );
					}
				});
			});
		}	
	},onSubmit :  function(ev){
		if(!this.validate()) Event.stop(ev);
	},validate : function(info) {
		var result = false;
		var useTitles = this.options.useTitles;
		var callback = this.options.onElementValidate;
		var checkReadOnly = this.options.checkReadOnly;
		var checkDisabled = this.options.checkDisabled;
		var notIgnoreHidden = this.options.notIgnoreHidden;
		
		if( Validation.mode.beforeValidAction ){
			Validation.mode.beforeValidAction();
		}
			
		if(this.options.stopOnFirst) {	
			result = Form.getElements(this.form).all(function(elm) { 
				return Validation.mode.validate(elm,{ notIgnoreHidden : notIgnoreHidden, useTitle : useTitles, onElementValidate : callback, checkReadOnly: checkReadOnly, checkDisabled: checkDisabled }, info); }
			);
		} else {
			result = Form.getElements(this.form).collect(function(elm) { 
				return Validation.mode.validate(elm,{ notIgnoreHidden : notIgnoreHidden, useTitle : useTitles, onElementValidate : callback, checkReadOnly: checkReadOnly, checkDisabled: checkDisabled }, info); }	
			).all();
		}
		
		if(!result && this.options.focusOnError) {
			var elements = Form.getElements(this.form).findAll(function(elm){
				return $(elm).hasClassName( Validation.mode.fail_css )
			});
			
			for( var i=0 ; i < elements.length ; i++ ){
				if( Validation.isVisible(elements[i]) && ! elements[i].disabled ){
					elements[i].focus();
					break;
				}
			}
		}

		//�h���ˮ�
		for( var method in this.verifyList ){
			for( var i=0 ; i < this.verifyList[method].length ; i++ ){    		//��X���X�զh���ˮ�method
				var params = this.verifyList[method][i];
				var inputs = params["input"];
				var options = params["option"];
				result = Validation.mode.multiValidate( method , inputs , options ) && result;
			}
		}

		if( Validation.mode.afterValidAction ){
			Validation.mode.afterValidAction( this.options );
		}

		this.options.onFormValidate(result, this.form);

		return result;
	},
	reset : function( isOnlyForm ){
		Form.getElements(this.form).each(
			function(elm){
				Validation.mode.reset(elm);
			}
		);
		
		if( ! isOnlyForm === true ){
			this.verifyReset();
		}
	},
	eraseMoney : function() {
			Form.getElements(this.form).findAll(function(elm){return $(elm).hasClassName('validate-number')}).each(function(e){
			var v = Validation.getElementValue(e);
			if (Validation.get('IsEmpty').test(v)){ 
				v = v.split(',').join('');
				e.setValue(v);
			}
			
		});
	},
	transformMoney : function() {
		Form.getElements(this.form).findAll(function(elm){return $(elm).hasClassName('validate-number')}).each(function(e){
			var v = Validation.getElementValue(e);
			if (Validation.get('IsEmpty').test(v)){
				v = v.replace(/^(\d+)((\.\d+)?)$/,function(s,s1,s2){return s1.replace(/\d{1,3}(?=(\d{3})+$)/g,"$&,")+s2;});
				e.setValue(v);
			}
			
		});
	},
	define : function( method_name, inputs , options ){   //�ۭq�h����쪺�ˮ�
		options = options || this.options;
		var params = { input : inputs , option : options };
				
		if(! this.verifyList[method_name]){
			this.verifyList[method_name] = [];
		}
		this.verifyList[method_name].push( params );
	},
	clear : function(){		//�M���h���ˮֶ���
		this.verifyList = {};
	},
	verifyReset: function(){
		for( var method in this.verifyList ){
			for( var i=0 ; i < this.verifyList[method].length ; i++ ){
				var params = this.verifyList[method][i];
				var inputs = params["input"];
				
				if( inputs instanceof Array ){
					for(var j=0 ; j < inputs.length ; j++ ){	//��method�w�q�F�X��inputs���ˮ�
						Validation.mode.reset(inputs[j]["id"]);
					}
				}else{
					Validation.mode.reset(inputs["id"]);
				}
			}
		}
	}
});

//�N���validate�ܰʪ�������X�Ӧ����@��class (�㦳validate() , test() , reset() ) ������
Validation.manner= {
	"validate" : { 	//������ڧ�ꪺ�ˮ֮ĪG
		pass_css : "validation-passed",
		fail_css : "validation-failed",
		m_fail_css: "m_validation-failed",
		advice_css: "validation-advice",
		validate : function(elm, options, info){
			options = Object.extend({
				useTitle : false,
				onElementValidate : function(result, elm) {}
			}, options || {});
			elm = $(elm);

			if(!options.checkReadOnly && elm.readOnly) { return true; }
			if(!options.checkDisabled && elm.disabled == true) { return true; }
			
			var cn = elm.classNames();
			
			var testMethod = this;
			return cn.all(function(value) {
				var test = testMethod.test(value,elm,options.useTitle,info ,options.notIgnoreHidden );
				options.onElementValidate(test, elm);
				return test;
			});
		},
		test : function(name, elm, useTitle, info, notIgnoreHidden ) {
			var v = Validation.get(name);
			try {
				var pass_css = this.pass_css;	
				var isVisible = notIgnoreHidden ? true : Validation.isVisible(elm);
				
				if( isVisible && ! v.test( $F(elm), elm, info)) {
					var errorMsg = useTitle ? ((elm && elm.title) ? elm.title : v.error) : v.error;
					var advice = this.getAdvice(name, elm);
				
					if( ! advice ) {
						advice = this.createAdvice(this.advice_css , name , elm , errorMsg);
						if( elm.type ){
							switch (elm.type.toLowerCase()) {
								case 'checkbox':
								case 'radio':
									var p = elm.parentNode;
									if(p) {
										Element.insert( p, { bottom : advice } );
									} else {
										Element.insert( elm, { after : advice } );									
									}
									break;
								default:
									Element.insert( elm , { after : advice } );	
							}
						}else{
							Element.insert( elm , { after : advice } );	
						}
					}else{
						advice.update(errorMsg);
					}

					advice.style.display = 'block';
					advice.removeClassName("validation-advice-disabled");
					
					elm.removeClassName( pass_css);
					elm.addClassName(this.fail_css);
					Validation.addError( elm , name , this.fail_css );
					return false;
				} else {
					var advice = this.getAdvice(name, elm);
					
					if( advice ){ 
						advice.style.display = "none";
						advice.addClassName("validation-advice-disabled");
					}	
					var result = Validation.removeError( elm , v.className , this.fail_css );
					if( result["result"] ){
						elm.addClassName( pass_css );				
					}
					
					if ( result["remove"] ){
						elm.removeClassName( this.fail_css );				
					}
					return true;
				}
			} catch(e) {
				throw(e)
			}
		},reset : function(elm) {
			elm = $(elm);
			
			var errors = Validation.getErrorArray( elm );	//���Xelement��ErrorPool,������advice
			for( var i=0 ; i < errors.length ; i++ ){
				var value = errors[i];
				var advice = this.getAdvice(value, elm);
				if( advice ){
					advice.style.display = "none";
					advice.addClassName("validation-advice-disabled");
				}	
			}
			
			elm.removeClassName(this.pass_css);
			elm.removeClassName(this.fail_css);
			elm.removeClassName(this.m_fail_css);
			Validation.clearCustomAttribute( elm );
		},multiValidate : function( validation_name , elms, options ){
			var notIgnoreHidden = ( options && options.notIgnoreHidden === true ) || false;

			var elements = Validation.getMultiTestElements( elms , options);
			if( elements === true ){
				return true;
			}
			return this.multiTest( validation_name , elements[0] , elements[1] , options.useTitle , notIgnoreHidden);
		},multiTest : function( validation_name , elms , inputs , useTitle , notIgnoreHidden) {
			var v = Validation.get( validation_name );
			try {
				var checklist = inputs[inputs.length -1 ];		//���o�ˮ֪�DOM�C��
				if ( checklist.length == 1 ){					//�u���@�Ӥ�������,�NDOM����}�C�אּ�Ǥ@��DOM����				
					inputs[inputs.length -1 ] = checklist[0];
				}
				var isVisible = true;

				if( !notIgnoreHidden ){
					for( var i=0 ; i < checklist.length ; i++ ){
						if(! Validation.isVisible(checklist[i]) ){
							isVisible = false;
							break;
						}
					}
				}

				var pass_css = this.pass_css;					
				if( isVisible && !v.test( inputs , elms , { multiTest: true })) {					
					for( var i=0 ; i < checklist.length ; i++ ){
						if( ! elms[i]["ignore"] === true ){
							var elm = checklist[i];						
							
							var errorMsg;
							if( elms[i]["errMsg"] ){    //�ϥΪ̦��ۭq���ܡA�Φۭq��
								errorMsg = elms[i]["errMsg"];
							}else{						//���ϥ�title���ܥ�title,�_�h���ˮ�function��
								errorMsg = useTitle ? ((elm && elm.title) ? elm.title : v.error) : v.error;
							}
							
							var advice = this.getAdvice(validation_name , elm);

							if( !advice ) {		
								advice = this.createAdvice(this.advice_css , validation_name , elm , errorMsg);
								if( elm.type ){
									switch (elm.type.toLowerCase()) {
										case 'checkbox':
										case 'radio':
											var p = elm.parentNode;
											if(p) {
												Element.insert( p, { bottom : advice } );
											} else {
												Element.insert( elm, { after : advice } );									
											}
											break;
										default:
											Element.insert( elm , { after : advice } );	
									}
								}else{
									Element.insert( elm , { after : advice } );	
								}
							}else{
								advice.update(errorMsg);
							}

							advice.style.display = 'block';
							advice.removeClassName("validation-advice-disabled");
							
							elm.removeClassName( pass_css);
							elm.addClassName(this.m_fail_css);	
							Validation.addError( elm , validation_name , this.m_fail_css );
						}
					}
					return false;
				} else {
					for( var i=0 ; i < checklist.length ; i++ ){
						var elm = checklist[i];
						var advice = this.getAdvice(validation_name, elm);
						if(advice){ 
							advice.style.display = "none";
							advice.addClassName("validation-advice-disabled");
						}	
						var result = Validation.removeError( elm , v.className , this.m_fail_css );
						if( result["result"] ){
							elm.addClassName( pass_css );				
						}
						
						if ( result["remove"] ){
							elm.removeClassName( this.m_fail_css );				
						}				
					}
					return true;
				}
			} catch(e) {
				throw(e)
			}
		},createAdvice:function( advice_css , name , elm , errorMsg){
			var eleId = "advice-" + name + "-" + Validation.getElmID(elm);
			return new Element('div', {id:eleId})
				.addClassName(advice_css)
				.addClassName("validation-advice-disabled")
				.update(errorMsg)
				.hide();
		},getAdvice : function(name, elm) {
			return $('advice-' + name + '-' + Validation.getElmID(elm)) || $('advice-' + Validation.getElmID(elm));
		}
	},
	"validator" : //�����ꤺ��ꪺ�ˮ֮ĪG
	{
		pass_css : "validator-passed",
		fail_css : "validator-failed",
		m_fail_css : "m_validator-failed",	
		errMsg : "" ,
		validate : function(elm, options, info){
			options = Object.extend({
				useTitle : false,
				onElementValidate : function(result, elm) {}
			}, options || {});
			elm = $(elm);

			if(!options.checkReadOnly && elm.readOnly) { return true; }
			if(!options.checkDisabled && elm.disabled == true) { return true; }
			
			var cn = elm.classNames();
			
			var testMethod = this;
			return result = cn.all(function(value) {
				var test = testMethod.test(value,elm,options.useTitle,info, options.notIgnoreHidden );
				options.onElementValidate(test, elm);
				return test;
			});
		},
		test : function(name, elm, useTitle, info , notIgnoreHidden) {
			var v = Validation.get(name);
					
			try {
				var pass_css = this.pass_css;		
				var isVisible = notIgnoreHidden ? true : Validation.isVisible(elm);

				var verifyValue;
				if(elm.readAttribute('datatype') === 'ROCDATE'){
					verifyValue = $(elm).value;
				}else{
					verifyValue = $F(elm);
				}

				if( isVisible && !v.test(verifyValue, elm, info)) {

					
					var fieldName = elm.getAttribute("fieldName") || "" ; 
					var errorMsg = useTitle ? ((elm && elm.title) ? elm.title : v.error) : v.error;
					
					errorMsg = fieldName + " [" + errorMsg + "]";
					this.errMsg = this.errMsg + errorMsg + '\n';

					Validation.addError( elm , name , this.fail_css );				
					elm.removeClassName( pass_css );
					elm.addClassName( this.fail_css );
									
					//�ΨӰ��Y���ˮ֪�alert
					if( info  && info.showAlert === true){	//�]��info�i�ǥi����,�ҥH�n���P�_undefined 
						alert( errorMsg );
					}
					
					return false;
				} else {
					var result = Validation.removeError( elm , v.className , this.fail_css );
					if( result["result"] ){
						elm.addClassName( pass_css );				
					}
					
					if ( result["remove"] ){
						elm.removeClassName( this.fail_css );				
					}
								
					return true;
				}
			} catch(e) {
				throw(e)
			}
		},reset : function(elm) {
			elm = $(elm);	
			this.errMsg = '';
			elm.removeClassName(this.fail_css);
			elm.removeClassName(this.pass_css);
			elm.removeClassName(this.m_fail_css);
			Validation.clearCustomAttribute( elm );
		}, beforeValidAction : function(){
			this.errMsg = '';
		}, afterValidAction : function( options ){
			if ( this.errMsg != '' ){
				this.errMsg =  ( options.alertTitle || "" ) + '�ˮֿ��~�p�U:\n' + this.errMsg;
				alert( this.errMsg);
			}
		},multiValidate : function( validation_name , elms, options ){
			var elements = Validation.getMultiTestElements( elms , options);
			if( elements === true ){
				return true;
			}
			var notIgnoreHidden = ( options && options.notIgnoreHidden === true ) || false;
			return this.multiTest( validation_name , elements[0] , elements[1] , options.useTitle, notIgnoreHidden );
		},multiTest : function( validation_name , elms , inputs , useTitle, notIgnoreHidden ) {
			var v = Validation.get( validation_name );
			
			try {
				var checklist = inputs[inputs.length -1 ];		//���o�ˮ֪�DOM�C��
				if ( checklist.length == 1 ){					//�u���@�Ӥ�������,�NDOM����}�C�אּ�Ǥ@��DOM����				
					inputs[inputs.length -1 ] = checklist[0];
				}
				
				var isVisible = true;
				
				if( !notIgnoreHidden ){
					for( var i=0 ; i < checklist.length ; i++ ){
						var elm = checklist[i];
						if(! Validation.isVisible(elm)){
							isVisible = false;
							break;
						}
					}
				}
				
				var pass_css = this.pass_css;			
				if( isVisible && !v.test( inputs , elms , { multiTest: true })) {
					for( var i=0 ; i < checklist.length ; i++ ){
						if( ! elms[i]["ignore"] === true ){
							var elm = checklist[i];					
							var name = elm.id || elm.name;
							var fieldName = elm.getAttribute("fieldName") || "" ;
				
							var errorMsg = '';
							if( elms[i]["errMsg"] ){    //�ϥΪ̦��ۭq���ܡA�Φۭq��
								errorMsg = elms[i]["errMsg"];
							}else{						//���ϥ�title���ܥ�title,�_�h���ˮ�function��
								errorMsg = useTitle ? ((elm && elm.title) ? elm.title : v.error) : v.error;
							}
							
							errorMsg = fieldName + " [" + errorMsg + "]";
							this.errMsg = this.errMsg + errorMsg + '\n'; 
												
							//��@�ˮ֪�pass_css
							Validation.addError( elm , validation_name,this.m_fail_css);
							elm.removeClassName(pass_css);				//��pass css����!!					
							elm.addClassName(this.m_fail_css);							
						}
					}
					return false;
				} else {
					for( var i=0 ; i < checklist.length ; i++ ){
						var elm = checklist[i];
						var result = Validation.removeError( elm , validation_name , this.m_fail_css );
						if( result["result"] ){
							elm.addClassName( pass_css );				
						}
						
						if ( result["remove"] ){
							elm.removeClassName( this.m_fail_css );				
						}						
					}
					return true;
				}
			} catch(e) {
				throw(e)
			}
		}	
	}
}

//��l�� validation ���Ҧ� (�Ѩt�ΨM�w�w�]�Ҧ�)
if( typeof CSRUtil == "object" && CSRUtil.UICore && CSRUtil.UICore.isOnTheSys( ['DS'] )){
	Validation.defaultManner = "validator";
	Validation.mode = Validation.manner["validator"];
}else{
	Validation.defaultManner = "validate";
	Validation.mode = Validation.manner["validate"];			//�w�]���ˮ֤覡
}

Validation.PREFIX = "data-__validation";						//�ۭq�ݩʥΪ��e�m��
Validation.ERROR_POOL = Validation.PREFIX + "ErrorPool";		//�ۭq�ݩʡA�ΨӰO��element�������ˮֿ��~

//Class Methods	
Object.extend(Validation, {
	validate : function(elm, options, info){
		if( options && options.mode ){
			return Validation.manner[options.mode].validate(elm, options, info);
		}
		return Validation.mode.validate(elm, options, info);
	},
	test : function(name, elm, useTitle, info) {
		if( info && info.mode ){
			return Validation.manner[info.mode].test(name, elm, useTitle, info);
		}
		return Validation.mode.test(name, elm, useTitle, info);
	},
	isVisible : function(elm) {
		while(elm.tagName != 'BODY') {
			if(!$(elm).visible()) return false;
			elm = elm.parentNode;
		}
		return true;
	}
	,
	getElmID : function(elm) {
		return elm.id ? elm.id : elm.name;
	},
	reset : function(elm) {
		for( var mode in Validation.manner ){
			Validation.manner[mode].reset( elm );
		}
	},
	add : function(className, error, test, options) {
		Validation.methods[className] = new Validator( className ,error ,test ,options);	
	},
	addAllThese : function(validators) {
		$A(validators).each(function(value) {
			Validation.methods[value[0]] = new Validator(value[0], value[1], value[2], (value.length > 3 ? value[3] : {}));
		});
	},
	get : function(name) {
		return  Validation.methods[name] ? Validation.methods[name] : Validation.methods['_LikeNoIDIEverSaw_'];
	},
	methods : {
		'_LikeNoIDIEverSaw_' : new Validator('_LikeNoIDIEverSaw_','',{})
	},
	getAdvice : function(name, elm) {
		return $('advice-' + name + '-' + Validation.getElmID(elm)) || $('advice-' + Validation.getElmID(elm));
	},
	getMode: function(name){
		return Validation.manner[name];
	},
	setMode: function(name){
		Validation.mode = Validation.manner[name];
	},
	multiValidate : function( validation_name , elms, options){	 	
		options = options || {};
		if( options.mode ){
			return Validation.manner[options.mode].multiValidate( validation_name , elms , options );
		}		
		return Validation.mode.multiValidate( validation_name , elms , options );
	},
	multiTest : function( validation_name , elms , inputs , useTitle ){
		return Validation.mode.multiTest( validation_name , elms , inputs , useTitle);
	},
	addError:function( elm , method_name , fail_css ){	//�bhtml DOM element�W�O���ˮ֪����~��T
		var errors = Validation.getErrorArray( elm );
		if(  errors.indexOf(method_name) == -1 ){	    //�ثe�S���o�ӿ��~
			var error = elm.getAttribute( Validation.ERROR_POOL ) || '';
			error =  error.length > 0 ? error + ' ' + method_name : method_name;
			elm.setAttribute( Validation.ERROR_POOL , error );
			var fail_css = Validation.PREFIX + fail_css;
			var error_count = elm.getAttribute( fail_css ) ? new Number(elm.getAttribute( fail_css )) + 1 : 1;
			elm.setAttribute( fail_css , error_count );
		}	
	},
	removeError:function( elm , method_name , fail_css ){	//�bhtml DOM element�W�����ˮ֪����~��T,�æ^�ǵ��G
		var errors = Validation.getErrorArray( elm );
		var result = false;
		var remove = false;
		
		var index =	errors.indexOf(method_name);
		if(  index >= 0 ){		   //�w�g���o�ӿ��~�F
			errors = Validation.removeErrorArray( elm , errors , method_name );
			
			var fail_css = Validation.PREFIX + fail_css;
			var error_count = new Number(elm.getAttribute( fail_css ))-1;
			if( error_count == 0 ){
				elm.removeAttribute( fail_css );	
				remove= true;
			}else{
				elm.setAttribute( fail_css , error_count );
			}
		}		
		
		if( errors.length == 0 ){	//���׬OString�άOArray,length=0���N���S���~�F
			result = true;
		}
		
		return { "result" : result , "remove" : remove };				
	},
	focusNextErrorElement: function( input ){	//��J�I����U�@�ӿ��~
		var nextErrors = Element.select( document.body , '['+ Validation.ERROR_POOL + ']' );
		if( nextErrors && nextErrors.length > 0 ){
			var compare;
			if( input.compareDocumentPosition ){	//�����s�������䴩DOM Level3
				compare = function( input , next ){
					if( input.compareDocumentPosition( next ) == 4 ){ //nextError�binput����
						return true;
					}
					return false;
				}
			}else{
				if( input.sourceIndex ){
					compare = function( input , next ){	//IE only
						if( next.sourceIndex > input.sourceIndex ){		//nextError�binput����
							return true;
						}
						return false;
					}
				}				
			}
			
			if( compare ){
				for( var i = 0 ; i < nextErrors.length ; i++ ){
					if( compare( input , nextErrors[i] ) ){
						if( Validation.isVisible(nextErrors[i]) && ! nextErrors[i].disabled ){
							nextErrors[i].focus();
							return;
						}
					}
				}
			}
			
			if( Validation.isVisible(nextErrors[0]) && !nextErrors[0].disabled ){
				nextErrors[0].focus();
			}
		}
	},
	clearCustomAttribute: function(elm){	//�M�� element �����~��T
		var attrs = elm.attributes;
		for( var i = attrs.length-1 ; i >= 0  ; i-- ){
			if( attrs[i].name.indexOf(Validation.PREFIX) == 0 ){
				elm.removeAttribute( attrs[i].name );
			}
		}	
	},
	getElementValue: function(elm){
		var tagName = elm.tagName;
		switch(tagName){
			case 'DIV':
			case 'SPAN':
				return elm.innerHTML;
			case 'SELECT':
				return elm.value;
			default:
				return Object.isFunction(elm.getValue)?elm.getValue():elm.value;
		}
	},getErrorArray: function( elm ){
		var errors = elm.getAttribute( Validation.ERROR_POOL ) || "" ;
		return errors.split(" ");
	},removeErrorArray : function( elm , errors , method_name ){
		var error = '';
		for( var i = 0 ; i < errors.length ; i++ ){
			if( errors[i] == method_name ){
				continue;
			}
			error = error + errors[i] + " ";
		}
		
		if( error.length > 0 ){
			error = error.slice(0 , -1);	//�h�̫�@�Ӫť�
		}
		elm.setAttribute( Validation.ERROR_POOL , error );
		return error;
	},getMultiTestElements: function( elms , options){
		var values = [];
		if( elms instanceof Array ){
			var inputs = [];
			for(var i=0 ; i < elms.length ; i++ ){
				var elm =  $( elms[i]["id"] );	
				if( !options.checkReadOnly && elm.readOnly) { return true; }
				if( !options.checkDisabled && elm.disabled == true) { return true; }
				values.push(Validation.getElementValue(elm));
				inputs.push(elm);		
			}
			values.push( inputs );
		}else if( typeof elms == "object" ){
			var id = elms["id"];
			elms = [ elms ];
			var elm =  $(id);
			if( !options.checkReadOnly && elm.readOnly) { return true; }
			if( !options.checkDisabled && elm.disabled == true) { return true; }	
			values.push(Validation.getElementValue(elm));
			values.push([ elm ]);
		}else if( typeof elms == "string" ){			
			var elm =  $( elms );
			if( !options.checkReadOnly && elm.readOnly) { return true; }
			if( !options.checkDisabled && elm.disabled == true) { return true; }
			elms = [{ id : elms }];
			values.push(Validation.getElementValue(elm));
			values.push([ elm ]);
		}
		 
		return [ elms , values ];
	}	
});


Validation.add('IsEmpty', '', function(v) {
				return  ((v == null) || (v.length == 0)); // || /^\s+$/.test(v));
			});

Validation.addAllThese([
	['required', '���i�ť�.', function(v) {
				return !Validation.get('IsEmpty').test(v);
			}],
	['validate-number', '�п�J���ļƦr�榡.', function(v) {
				return Validation.get('IsEmpty').test(v) || /^[+-]?[\d\,]*\.?\d*([eE][+-]?\d+)?$/.test(v);
			}],
	['validate-positive-number', '�п�J���ĥ���.', function(v) {
				return Validation.get('IsEmpty').test(v) || (!isNaN(v) && /^(\d)?\d*(\.\d*)?$/.test(v));
			}],
    ['validate-integer', '�п�J���ľ��.', function(v) {
				return Validation.get('IsEmpty').test(v) || /^(-)?\d*$/.test(v);
			}],
	['validate-digits', '�п�J���ĥ����.', function(v) {
				return Validation.get('IsEmpty').test(v) || /^\d+$/.test(v);
			}],
	['validate-positive', '�п�J�j��s�����ĥ����.', function(v) {
				return Validation.get('validate-digits').test(v);
			}, {gt:0}],
	['validate-greater-than-zero', '�п�J�j��s�����ļƦr�榡.', function(v) {
				return Validation.get('validate-number').test(v);
			}, {gt:0}],
	['validate-alpha', '�п�J�^��r��.', function (v) {
				return Validation.get('IsEmpty').test(v) || /^[a-zA-Z]+$/.test(v)
			}],
	['validate-alphanum', '�п�J���Ĥ�Ʀr.', function(v) {
				return Validation.get('IsEmpty').test(v) || !/\W/.test(v) || /[^u4e00-u9fa5]/.test(v)
			}],
	['validate-date', '�п�J���Ĥ���榡.', function(v) {
				var test = new Date(v);
				return Validation.get('IsEmpty').test(v) || !isNaN(test);
			}],
	['validate-email', '�п�J���Ĺq�l�l��a�}�榡.', function (v) {
				return Validation.get('IsEmpty').test(v) || /\w{1,}[@][\w\-]{1,}([.]([\w\-]{1,})){1,}$/.test(v)
			}],
	['validate-url', '�п�J���ĺ��}.', function (v) {
				return Validation.get('IsEmpty').test(v) || /^(http|https|ftp):\/\/(([A-Z0-9][A-Z0-9_-]*)(\.[A-Z0-9][A-Z0-9_-]*)+)(:(\d+))?\/?/i.test(v)
			}],
	['validate-date-db', '���Ĥ���榡��: YYYY-MM-DD', function(v) {
				if(Validation.get('IsEmpty').test(v)) return true;
				var regex = /^(\d{4})\-(\d{2})\-(\d{2})$/;
				if(!regex.test(v)) return false;
				var d = new Date(v.replace(regex, '$1/$2/$3'));
				return ( parseInt(RegExp.$2, 10) == (1+d.getMonth()) ) && 
							(parseInt(RegExp.$3, 10) == d.getDate()) && 
							(parseInt(RegExp.$1, 10) == d.getFullYear() );
			}],
	['validate-currency-dollar', 'Please enter a valid $ amount. For example $100.00 .', function(v) {
				// [$]1[##][,###]+[.##]
				// [$]1###+[.##]
				// [$]0.##
				// [$].##
				return Validation.get('IsEmpty').test(v) ||  /^\$?\-?([1-9]{1}[0-9]{0,2}(\,[0-9]{3})*(\.[0-9]{0,2})?|[1-9]{1}\d*(\.[0-9]{0,2})?|0(\.[0-9]{0,2})?|(\.[0-9]{1,2})?)$/.test(v)
			}],
	['validate-selection', '�п��', function(v,elm){
				// return elm.options ? elm.selectedIndex > 0 : !Validation.get('IsEmpty').test(v);
				return !Validation.get('IsEmpty').test(v) || elm.selectedIndex > 0;
			}],
	['validate-one-required', '�Х����.', function (v,elm) {
				var p = elm.parentNode;
				var options = p.getElementsByTagName('INPUT');
				return $A(options).any(function(elm) {
					return $F(elm);
				});
			}],
	['validate-positive-integer', '�п�J�j��s�����ľ��.', function(v) {
				return Validation.get('validate-integer').test(v);
			}, {gt:0}]
]);

//���ݨϥ� date.js �~��ϥΪ��ˮ�
Validation.addAllThese([
	['validate-Date-Interval', '����_�����~', function( str_dt , end_dt , inputs ){
		if( !Validation.get('IsEmpty').test(str_dt) && !Validation.get('IsEmpty').test(end_dt) ){	//�T�{����J
			return diffDayY2K( str_dt , end_dt ) >= 0;
		}
		return true;
	}],
	['validate-ROCDate', '�п�J���T���������榡', function(v) {
		if( !Validation.get('IsEmpty').test(v) ){
			return isROCdate(v,false);
		}
		return true;
	}],
	['validate-ROCDate-Interval', '����_�����~', function(str_dt , end_dt , inputs ) {
		if( !Validation.get('IsEmpty').test(str_dt) && !Validation.get('IsEmpty').test(end_dt) ){	//�T�{����J		
			return diffDayROC(str_dt, end_dt ) >= 0;
		}
		return true;
	}],
	['validate-DateYM', '�п�J���T���褸�~��榡', function( v ) {
		return Validation.get('IsEmpty').test(v) || dateJs.isDateYM(v);
	}],
	['validate-ROCDateYM', '�п�J���T������~��榡', function( v ) {
		if(Validation.get('IsEmpty').test(v)){
			return true;
		}
		return dateJs.isDateYM(v, v.length<6);
	}]
]);

//���ݨϥ� validation.js �~��ϥΪ��ˮ� ( CM\js �U��)
Validation.addAllThese([
	['checkInputLength', '��J�ȶW�X���׭���', function( v , element  ) {
		return validation.checkInputLength( v , element.maxLength );
	}],
	['checkUniSN', '�Τ@�s���榡���~', function( v ) {
		return validation.checkUniSN( v );
	}],
	['hasFullType', '���i��J�b����r', function( v ) {
		return !validation.hasHalfType( v );
	}],
	['hasHalfType', '���i��J������r', function( v ) {
		return !validation.hasFullType( v );
	}],
	['checkROCID', '�����Ҧr���榡���~', function( v ) {
		return validation.checkROCID( v );
	}],
	['checkROCPassport', '�@�Ӹ��X�榡���~', function( v ) {
		return validation.checkROCPassport( v );
	}],
	['checkROCARC', '�~�d�Ҹ��X�榡���~', function( v ) {
		return validation.checkROCARC( v );
	}],
	['checkID', '�ҥ�榡���~', function( v ) {
		return validation.checkID( v );
	}]
])