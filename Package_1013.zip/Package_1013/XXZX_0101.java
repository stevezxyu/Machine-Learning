package com.cathay.xx.zx.trx;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.message.MessageHelper;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.IConstantMap;
import com.cathay.rz.n0.module.RZ_N0Z001;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.cathay.xx.vo.DTXXTP01;
import com.cathay.xx.zx.module.XX_ZX0100;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Version Description Author
 * 2016/04/27  1.0 Created �i����
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    ���u�򥻸�ƺ��@
 * �{���W��    XXZX_0101.java
 * �@�~�覡    ONLINE
 * ���n����    (1) �s�W
 *          (2) �ק�
 *          (3) ����
 *          (4) �f��
 *          (5) �h�^
 *          (6) �R��
 * ���s���v    FUNC_ID = ZZZX0101
 * </pre>
 * @author �E���V
 * @since 2017/10/5
 */
@SuppressWarnings("unchecked")
public class XXZX_0101 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(XXZX_0101.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); // �@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); // �I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, �γ]�w ReturnMessage �� response
     * code.
     */
    private void initApp(RequestContext req) {
        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        resp.setResponseCode("success");
    }

    /**
     * ��l
     */
    public ResponseContext doPrompt(RequestContext req) {
        VOTool.setParamsFromLP_JSON(req);
        
        //clear all
        //String temp = req.getParameter("EMP_ID");
        String ACTION_TYPE = req.getParameter("ACTION_TYPE");
        resp.addOutputData("reQuery_param", req.getParameter("reQuery_param"));//TODO �O�d�W�@���d�߰Ѽ�
      
        if ("U".equals(ACTION_TYPE)) {
            //�d�߶i�J
            // U :�ק��
            //resp.addOutputData("ACTION_TYPE", "U"); //EMP_ID�O���Ȫ��ɭ԰�Update
            Map reqMap = new HashMap();
            reqMap.put("EMP_ID", req.getParameter("EMP_ID"));

            try {
                this.query(reqMap, new XX_ZX0100());
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "�d�ߧ���");
            } catch (ErrorInputException eie) {
                log.error("eie", eie);
                MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
            } catch (DataNotFoundException dnfe) {
                log.error("�d�L���", dnfe);
                MessageHelper.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "�d�L���");
            } catch (ModuleException me) {
                if (me.getRootException() == null) {
                    log.error("�d�ߥ���", me);
                    MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
                } else {
                    log.error(me.getMessage(), me.getRootException());
                    if (me.getRootException() instanceof OverCountLimitException) {
                        MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��");
                    } else {
                        MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "�d�ߥ���", me, req);
                    }
                }
            } catch (Exception e) {
                log.error("�d�ߥ���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.ERROR, "�d�ߥ���", e, req);
            }
        } else {
            //�s�Winsert�����A
            //I :�s�W�� 
            ACTION_TYPE = "I";//EMP_ID�O�S���Ȫ��ɭ԰�Insert
            //resp.addOutputData("ACTION_TYPE", "I"); //EMP_ID�O�S���Ȫ��ɭ԰�Insert
            resp.addOutputData("OP_STATUS_NM", "��J��");
            resp.addOutputData("UPDT_NM", user.getEmpName()); //��ܦW�l,if �P�_�ݭn��update��insert
            resp.addOutputData("UPDT_DATE", DATE.today());
        }
        resp.addOutputData("ACTION_TYPE", ACTION_TYPE);
        
        return resp;
    }
    
    /**
     * �s�W
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {

        try {
            Map reqMap = this.doput(req);

            XX_ZX0100 theXX_ZX0100 = new XX_ZX0100();
            Transaction.begin();
            try {
                theXX_ZX0100.insert(reqMap, user); //class
                // if(true)throw new Exception();
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            resp.addOutputData("ACTION_TYPE", "U");
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "�s�W����");
            try {
                this.query(reqMap, theXX_ZX0100);
            } catch (DataNotFoundException dnfe) {
                log.error("�s�W�����A�d�L���", dnfe);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "�s�W�����A�d�L���");
            } catch (Exception e) {
                log.error("�s�W�����A���d����", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "�s�W�����A���d����");
            }
        } catch (ErrorInputException eie) {
            log.error("eie", eie);
            MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageHelper.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "�d�L���");
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�s�W����", me);
                MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "�s�W���ƶW�X�t�έ���A���Y�p�d�߽d��");
                } else {
                    MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "�s�W����", me, req);
                }
            }
        } catch (Exception e) {
            log.error("�s�W����", e);
            MessageHelper.setReturnMessage(msg, ReturnCode.ERROR, "�s�W����", e, req);
        }
        return resp;
    }

    /** 
     * �ק�
     * @param req
     * @return
     */
    public ResponseContext doRevise(RequestContext req) {
        try {
            Map reqMap = this.doput(req);
            XX_ZX0100 theXX_ZX0100 = new XX_ZX0100();
            Transaction.begin();
            try {
                theXX_ZX0100.update(reqMap, user); //class
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "�ק粒��");
            try {
                this.query(reqMap, theXX_ZX0100);
            } catch (DataNotFoundException dnfe) {
                log.error("�ק粒���A�d�L���", dnfe);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "�s�W�����A�d�L���");
            } catch (Exception e) {
                log.error("�ק粒���A���d����", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "�s�W�����A���d����");
            }
        } catch (ErrorInputException eie) {
            log.error("eie", eie);
            MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageHelper.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "�d�L���");
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�d�L����", me);
                MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "�קﵧ�ƶW�X�t�έ���A���Y�p�d�߽d��");
                } else {
                    MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "�ק異��", me, req);
                }
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageHelper.setReturnMessage(msg, ReturnCode.ERROR, "�ק異��", e, req);
        }
        return resp;
    }

    /**
     * ����
     * @param req
     * @return
     */
    public ResponseContext doSubmit(RequestContext req) {
        resp.addOutputData("ACTION_TYPE", "I");
        try {
            Map reqMap = this.doput(req);

            XX_ZX0100 theXX_ZX0100 = new XX_ZX0100();

            String FLOW_NO = MapUtils.getString(reqMap, "FLOW_NO");

            DTXXTP01 vo = new DTXXTP01();
            String EMP_ID = MapUtils.getString(reqMap, "EMP_ID");
            vo.setEMP_ID(EMP_ID);

            Transaction.begin();
            try {
              
                new RZ_N0Z001().approveFlow(FLOW_NO, "����", "", user.getEmpID(), user.getDivNo());
                theXX_ZX0100.confirm(vo); //�NreqMap�নvo
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            resp.addOutputData("ACTION_TYPE", "U");
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "���槹��");
            try {
                this.query(reqMap, theXX_ZX0100);
            } catch (DataNotFoundException dnfe) {
                log.error("���槹���A�d�L���", dnfe);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "���槹���A�d�L���");
            } catch (Exception e) {
                log.error("���槹���A���d����", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "���槹���A���d����");
            }
        } catch (ErrorInputException eie) {
            log.error("eie", eie);
            MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageHelper.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "�d�L���");
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("���楢��", me);
                MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "���浧�ƶW�X�t�έ���A���Y�p�d�߽d��");
                } else {
                    MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "���楢��", me, req);
                }
            }
        } catch (Exception e) {
            log.error("���楢��", e);
            MessageHelper.setReturnMessage(msg, ReturnCode.ERROR, "���楢��", e, req);
        }
        return resp;
    }

    /**
     * �f��
     * @param req
     * @return
     */
    public ResponseContext doAudit(RequestContext req) {
        try {
            Map reqMap = this.doput(req);
            XX_ZX0100 theXX_ZX0100 = new XX_ZX0100();

            String FLOW_NO = MapUtils.getString(reqMap, "FLOW_NO");

            DTXXTP01 vo = new DTXXTP01();
            String EMP_ID = MapUtils.getString(reqMap, "EMP_ID");
            vo.setEMP_ID(EMP_ID);
            Transaction.begin();
            try {
                new RZ_N0Z001().approveFlow(FLOW_NO, "�f��", "", user.getEmpID(), user.getDivNo());
                theXX_ZX0100.approve(vo); //�NreqMap�নvo
                Transaction.commit();

            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "�f�֧���");
            try {
                this.query(reqMap, theXX_ZX0100);
            } catch (DataNotFoundException dnfe) {
                log.error("�f�֧����A�d�L���", dnfe);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "�f�֧����A�d�L���");
            } catch (Exception e) {
                log.error("�f�֧����A���d����", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "�f�֧����A���d����");
            }
        } catch (ErrorInputException eie) {
            log.error("eie", eie);
            MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageHelper.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "�d�L���");
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�f�֥���", me);
                MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "�f�֥浧�ƶW�X�t�έ���A���Y�p�d�߽d��");
                } else {
                    MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "�f�֥���", me, req);
                }
            }
        } catch (Exception e) {
            log.error("�f�֥���", e);
            MessageHelper.setReturnMessage(msg, ReturnCode.ERROR, "�f�֥���", e, req);
        }
        return resp;
    }

    /**
     * �h�^
     * @param req
     * @return
     */
    public ResponseContext doBack(RequestContext req) {
        resp.addOutputData("ACTION_TYPE", "I");
        try {
            Map reqMap = this.doput(req);
            XX_ZX0100 theXX_ZX0100 = new XX_ZX0100();

            String FLOW_NO = MapUtils.getString(reqMap, "FLOW_NO");

            DTXXTP01 vo = new DTXXTP01();
            String EMP_ID = MapUtils.getString(reqMap, "EMP_ID");
            vo.setEMP_ID(EMP_ID);
            Transaction.begin();

            try {
                System.err.println("FLOW_NO:" + FLOW_NO);
                new RZ_N0Z001().rejectFlow(FLOW_NO, "�h�^", "", user.getEmpID(), user.getDivNo());
                theXX_ZX0100.reject(vo); //�NreqMap�নvo       
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "�h�^����");
            try {
                this.query(reqMap, theXX_ZX0100);
            } catch (DataNotFoundException dnfe) {
                log.error("�h�^�����A�d�L���", dnfe);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "�h�^�����A�d�L���");
            } catch (Exception e) {
                log.error("�h�^�����A���d����", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "�h�^�����A���d����");
            }
        } catch (ErrorInputException eie) {
            log.error("eie", eie);
            MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageHelper.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "�d�L���");
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�h�^����", me);
                MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "�h�^�浧�ƶW�X�t�έ���A���Y�p�d�߽d��");
                } else {
                    MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "�h�^����", me, req);
                }
            }
        } catch (Exception e) {
            log.error("�h�^����", e);
            MessageHelper.setReturnMessage(msg, ReturnCode.ERROR, "�h�^����", e, req);
        }
        return resp;
    }

    /**
     * �R��
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        resp.addOutputData("ACTION_TYPE", "I");
        try {
            String EMP_ID = req.getParameter("EMP_ID");

            this.doput(req);

            Transaction.begin();
            try {
                new XX_ZX0100().delete(EMP_ID); //class
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "�R������");
        } catch (ErrorInputException eie) {
            log.error("eie", eie);
            MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageHelper.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "�d�L���");
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�R������", me);
                MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "�R�����ƶW�X�t�έ���A���Y�p�d�߽d��");
                } else {
                    MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "�R������", me, req);
                }
            }
        } catch (Exception e) {
            log.error("�R������", e);
            MessageHelper.setReturnMessage(msg, ReturnCode.ERROR, "�R������", e, req);
        }
        return resp;
    }

    /**
     * �@�άd��
     * @param reqMap
     * @throws ModuleException 
     */
    private void query(Map reqMap, XX_ZX0100 theXX_ZX0100) throws ModuleException {
        List<Map> resultList = theXX_ZX0100.query(reqMap); //�Ǧ^�ȦA���@��query�e�{�b����
        Map resultMap = resultList.get(0);
        resp.addOutputData("EMP_ID", resultMap.get("EMP_ID")); //��EL�覡�ᵹ�e�ݭ���
        resp.addOutputData("EMP_NAME", resultMap.get("EMP_NAME"));
        resp.addOutputData("DIV_NO", resultMap.get("DIV_NO"));
        resp.addOutputData("BIRTHDAY", resultMap.get("BIRTHDAY"));
        resp.addOutputData("POSITION", resultMap.get("POSITION"));
        resp.addOutputData("OP_STATUS_NM", resultMap.get("OP_STATUS_NM"));
        resp.addOutputData("UPDT_NM", resultMap.get("UPDT_NM"));
        resp.addOutputData("UPDT_DATE", resultMap.get("UPDT_DATE"));
        resp.addOutputData("OP_STATUS", resultMap.get("OP_STATUS"));
        resp.addOutputData("FLOW_NO", resultMap.get("FLOW_NO"));
        resp.addOutputData("resultMap",resultMap);
    }

    /** ���� map ��
     * @param req
     * @return
     */
    private Map doput(RequestContext req) {
        System.err.println("doput reQuery_param:"+req.getParameter("reQuery_param"));
        resp.addOutputData("reQuery_param", req.getParameter("reQuery_param"));//TODO �O�d�W�@���d�߰Ѽ�
        resp.addOutputData("ACTION_TYPE", req.getParameter("ACTION_TYPE"));
        String EMP_ID = req.getParameter("EMP_ID");
        String EMP_NAME = req.getParameter("EMP_NAME");
        String DIV_NO = req.getParameter("DIV_NO");
        String BIRTHDAY = req.getParameter("BIRTHDAY");
        String POSITION = req.getParameter("POSITION");
        String UPDT_NM = req.getParameter("UPDT_NM");
        String UPDT_DATE = req.getParameter("UPDT_DATE");
        String OP_STATS_NM = req.getParameter("OP_STATS_NM");
        String FLOW_NO = req.getParameter("FLOW_NO");

        //�O�d��e�����
        resp.addOutputData("EMP_ID", EMP_ID);
        resp.addOutputData("EMP_NAME", EMP_NAME);
        resp.addOutputData("DIV_NO", DIV_NO);
        resp.addOutputData("BIRTHDAY", BIRTHDAY);
        resp.addOutputData("POSITION", POSITION);
        resp.addOutputData("UPDT_NM", UPDT_NM);
        resp.addOutputData("UPDT_DATE", DATE.toTimestamp(UPDT_DATE));
        resp.addOutputData("OP_STATS_NM", OP_STATS_NM);
        resp.addOutputData("FLOW_NO", FLOW_NO);

        Map reqMap = new HashMap();
        reqMap.put("EMP_ID", EMP_ID);
        reqMap.put("EMP_NAME", EMP_NAME);
        reqMap.put("DIV_NO", DIV_NO);
        reqMap.put("BIRTHDAY", BIRTHDAY);
        reqMap.put("POSITION", POSITION);
        reqMap.put("UPDT_NM", UPDT_NM);
        reqMap.put("UPDT_DATE", UPDT_DATE);
        reqMap.put("OP_STATS_NM", OP_STATS_NM);
        reqMap.put("FLOW_NO", FLOW_NO);

        return reqMap;
    }

}
