package com.cathay.xx.zx.trx;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.message.MessageHelper;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.IConstantMap;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.cathay.xx.zx.module.XX_ZX0100;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

@SuppressWarnings("unchecked")
public class XXZX_0100 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(XXZX_0100.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); // �@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); // �I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, �γ]�w ReturnMessage �� response
     * code.
     */
    private void initApp(RequestContext req) {
        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        resp.setResponseCode("success"); //XML����(response name)
    }

    /**
     * ��l
     */
    public ResponseContext doPrompt(RequestContext req) {
        String reQuery_param = req.getParameter("reQuery_param"); //���oreQuery�Ѽ�
        try {
           //System.err.println("reQuery_param==>"+reQuery_param);
            if (StringUtils.isNotBlank(reQuery_param)) {    //�P�_�ѼƬO�_���ŭ�

                Map reQuery_param_Map = VOTool.jsonToMap(reQuery_param);    //�NreQuery���ɱq Json �� Map

                resp.addOutputData("EMP_ID", reQuery_param_Map.get("EMP_ID"));  //�A��ȶǦ^���W
                resp.addOutputData("DIV_NO", reQuery_param_Map.get("DIV_NO"));
                resp.addOutputData("INIT_QUERY", "Y");  //�Ǧ^��l�Ȫ��ɭԬ�Y�����s�d��
            }
        } catch (Exception e) {
            log.error("�B�z��d�߱����ƥ���", e);
        }

        return resp;
    }

    /**
     * �d��
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            int nowPage = req.getParameter("nowPage") == null ? 0 : Integer.parseInt(req.getParameter("nowPage"));
            String inx = req.getParameter("inxPage");
            String nwPg = req.getParameter("nwPg");
            String EMP_ID = req.getParameter("EMP_ID");
            String DIV_NO = req.getParameter("DIV_NO");
            resp.addOutputData("EMP_ID", EMP_ID);
            resp.addOutputData("DIV_NO", DIV_NO);
            Map reqMap = new HashMap();
            reqMap.put("EMP_ID", EMP_ID);
            reqMap.put("DIV_NO", DIV_NO);

            XX_ZX0100 theXX_ZX0100 = new XX_ZX0100();
            List<Map> resultList = theXX_ZX0100.query(reqMap);
            resp.addOutputData("ResultListSize", resultList.size());
            //�C�����size��10�������
            int size = (resultList.size() / 10) + 1;
            //resultList = resultList.subList(10, 20); 

            //�إߤ����e���M�᭶
            System.err.println(inx);
            int listSize = resultList.size();
            if ("1".equals(inx)) { //�Ĥ@��
                nowPage = 0;
                //resultList = resultList.subList(nowPage * 10, (nowPage + 1) * 10);
            } else if ("2".equals(inx)) { //�W�@��
                nowPage--;
                //resultList = resultList.subList(nowPage * 10, (nowPage + 1) * 10);
            } else if ("3".equals(inx)) { //�U�@��
                nowPage++;

                //resultList = resultList.subList(nowPage * 10,  (nowPage + 1) * 10);
            } else if ("4".equals(inx)) { //�̫�@��
                System.err.println("resultList.size:" + resultList.size());
                nowPage = size - 1;
                //resultList = resultList.subList((resultList.size()) - (resultList.size() % 10), resultList.size());

            } else if ("5".equals(inx)) { //�U�Ԧ������Ȥ���ﭶ
                nowPage = (Integer.parseInt(nwPg) - 1);
                //resultList = resultList.subList(nowPage * 10, (nowPage + 1) * 10);
            } else if (resultList != null) {
                log.debug("resultList-->" + resultList);
                nowPage = 0;
                // resultList = resultList.subList(nowPage * 10, lastIndex);
            } else {
                throw new DataNotFoundException();
            }

            int lastIndex = (nowPage + 1) * 10;
            if (lastIndex > listSize) { //�Y�O10�����@������ƪ��פj�󥼺�10�����
                lastIndex = listSize;
            }
            resultList = resultList.subList(nowPage * 10, lastIndex);

          
            resp.addOutputData("resultList", resultList);

            resp.addOutputData("size", size);
            resp.addOutputData("nowPage", nowPage);

            

            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "�d�ߧ���");
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error(dnfe);
            MessageHelper.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "�d�L���");
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��");
                } else {
                    MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "�d�ߥ���", me, req);
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageHelper.setReturnMessage(msg, ReturnCode.ERROR, "�d�ߥ���", e, req);
        }
        return resp;
    }

    /*
        public ResponseContext doUpdate(RequestContext req) {
            try {
                String EMP_ID = req.getParameter("EMP_ID");
                String DIV_NO = req.getParameter("DIV_NO");

                //---------------------------------------

                Transaction.begin();
                try {
                    new XX_ZX0100().update();
                    
                    Transaction.commit();
                } catch (Exception e) {
                    Transaction.rollback();
                    throw e;
                }

                //----------------------------------------

                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "�d�ߧ���");
            } catch (ErrorInputException eie) {
                log.error(eie);
                MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
            } catch (DataNotFoundException dnfe) {
                log.error(dnfe);
                MessageHelper.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "�d�L���");
            } catch (ModuleException me) {
                if (me.getRootException() == null) {
                    log.error(me);
                    MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
                } else {
                    log.error(me.getMessage(), me.getRootException());
                    if (me.getRootException() instanceof OverCountLimitException) {
                        MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��");
                    } else {
                        MessageHelper.setReturnMessage(msg, ReturnCode.ERROR_MODULE, "�d�ߥ���", me, req);
                    }
                }
            } catch (Exception e) {
                log.error("�d�ߥ���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.ERROR, "�d�ߥ���", e, req);
            }

            return resp;
        }*/
}
