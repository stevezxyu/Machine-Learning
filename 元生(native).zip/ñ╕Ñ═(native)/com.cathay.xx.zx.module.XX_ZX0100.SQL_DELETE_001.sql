delete from DBXX.DTXXTP01
where EMP_ID = ':EMP_ID'